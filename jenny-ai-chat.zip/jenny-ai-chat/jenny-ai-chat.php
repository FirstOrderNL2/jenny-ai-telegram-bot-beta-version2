<?php
/**
 * Plugin Name: Jenny AI Crypto Chat
 * Description: A chatbot interface for cryptocurrency prices and news powered by AI
 * Version: 1.0.0
 * Author: StackBlitz
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('JENNY_AI_CHAT_VERSION', '1.0.0');
define('JENNY_AI_CHAT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('JENNY_AI_CHAT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load core plugin files
require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat.php';
require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-admin.php';
require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-shortcode.php';
require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-ajax.php';

// Initialize the plugin
function jenny_ai_chat_init() {
    $plugin = new Jenny_AI_Chat();
    $plugin->init();
}
add_action('plugins_loaded', 'jenny_ai_chat_init');