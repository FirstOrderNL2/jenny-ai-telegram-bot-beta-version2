<?php
class Jenny_AI_Chat {
    private $admin;
    private $shortcode;
    private $ajax;

    public function init() {
        // Load required files
        $this->load_dependencies();
        
        // Initialize components
        $this->admin = new Jenny_AI_Chat_Admin();
        $this->admin->init();

        $this->shortcode = new Jenny_AI_Chat_Shortcode();
        $this->shortcode->init();

        $this->ajax = new Jenny_AI_Chat_Ajax();
        $this->ajax->init();

        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
    }

    private function load_dependencies() {
        // Core files
        require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-admin.php';
        require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-shortcode.php';
        require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-ajax.php';
        require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/class-jenny-ai-chat-processor.php';
        
        // Services
        require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/services/class-jenny-ai-chat-crypto-service.php';
        require_once JENNY_AI_CHAT_PLUGIN_DIR . 'includes/services/class-jenny-ai-chat-ai-service.php';
    }

    public function register_assets() {
        wp_register_script(
            'jenny-ai-chat',
            JENNY_AI_CHAT_PLUGIN_URL . 'assets/js/jenny-ai-chat.js',
            array('jquery'),
            JENNY_AI_CHAT_VERSION,
            true
        );

        wp_register_style(
            'jenny-ai-chat',
            JENNY_AI_CHAT_PLUGIN_URL . 'assets/css/jenny-ai-chat.css',
            array(),
            JENNY_AI_CHAT_VERSION
        );

        wp_localize_script('jenny-ai-chat', 'jennyAiChat', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('jenny-ai-chat'),
            'defaultAvatar' => JENNY_AI_CHAT_PLUGIN_URL . 'assets/images/default-avatar.png'
        ));
    }
}