<?php
class Jenny_AI_Chat_Shortcode {
    public function init() {
        add_action('wp_footer', array($this, 'render_chat_widget')); // Changed to wp_footer
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function enqueue_assets() {
        wp_enqueue_style('jenny-ai-chat', JENNY_AI_CHAT_PLUGIN_URL . 'assets/css/jenny-ai-chat.css', array(), JENNY_AI_CHAT_VERSION);
        wp_enqueue_script('jenny-ai-chat', JENNY_AI_CHAT_PLUGIN_URL . 'assets/js/jenny-ai-chat.js', array('jquery'), JENNY_AI_CHAT_VERSION, true);
        wp_localize_script('jenny-ai-chat', 'jennyAiChat', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('jenny-ai-chat')
        ));
    }

    public function render_chat_widget() {
        include JENNY_AI_CHAT_PLUGIN_DIR . 'templates/chat-widget.php';
    }
}