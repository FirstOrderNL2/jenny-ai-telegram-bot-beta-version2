export class ChatToggle {
    constructor() {
        this.widget = document.querySelector('.jenny-ai-chat-widget');
        this.toggleButton = document.querySelector('.jenny-toggle-button');
        this.closeButton = document.querySelector('.jenny-close-button');
        this.bindEvents();
    }

    bindEvents() {
        this.toggleButton?.addEventListener('click', () => this.toggle());
        this.closeButton?.addEventListener('click', () => this.close());
        document.addEventListener('keydown', (e) => this.handleKeyPress(e));
        document.addEventListener('click', (e) => this.handleOutsideClick(e));
    }

    toggle() {
        if (this.widget) {
            this.widget.classList.toggle('active');
        }
    }

    close() {
        this.widget?.classList.remove('active');
    }

    handleKeyPress(e) {
        if (e.key === 'Escape') {
            this.close();
        }
    }

    handleOutsideClick(e) {
        if (this.widget?.classList.contains('active') && 
            !this.widget.contains(e.target) && 
            !this.toggleButton.contains(e.target)) {
            this.close();
        }
    }
}