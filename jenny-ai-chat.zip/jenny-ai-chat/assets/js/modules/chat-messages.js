export class ChatMessages {
    constructor() {
        this.container = document.getElementById('jenny-ai-chat-messages');
    }

    append(content, isUser = false) {
        if (!this.container) return;

        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'jenny-message'}`;
        messageDiv.textContent = content;
        
        this.container.appendChild(messageDiv);
        this.scrollToBottom();
    }

    scrollToBottom() {
        if (this.container) {
            this.container.scrollTop = this.container.scrollHeight;
        }
    }
}